package com.unfallen.mii30n;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Conexión con un adaptador OBD2 ELM327 por Bluetooth clásico (perfil serie SPP).
 * Solo transporta texto: la página envía comandos (ATZ, 010C, 03…) y recibe la respuesta
 * en bruto. Toda la interpretación de los datos se hace en la página.
 */
@SuppressLint("MissingPermission")
final class ObdClient {

    interface Sink {
        void event(String type, String data);

        void result(int id, String data);
    }

    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final long READ_TIMEOUT_MS = 5000;

    private final Context ctx;
    private final Sink sink;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private volatile BluetoothSocket socket;
    private InputStream in;
    private OutputStream out;

    ObdClient(Context ctx, Sink sink) {
        this.ctx = ctx;
        this.sink = sink;
    }

    private BluetoothAdapter adapter() {
        BluetoothManager m = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
        return m == null ? null : m.getAdapter();
    }

    /** Lista de dispositivos emparejados en JSON: {"devices":[{"name":..,"address":..}]} o {"error":..}. */
    String devices() {
        try {
            BluetoothAdapter a = adapter();
            if (a == null) return "{\"error\":\"nobt\"}";
            if (!a.isEnabled()) return "{\"error\":\"off\"}";
            JSONArray list = new JSONArray();
            Set<BluetoothDevice> bonded = a.getBondedDevices();
            if (bonded != null) {
                for (BluetoothDevice d : bonded) {
                    JSONObject o = new JSONObject();
                    String name = d.getName();
                    o.put("name", name == null ? "" : name);
                    o.put("address", d.getAddress());
                    list.put(o);
                }
            }
            JSONObject r = new JSONObject();
            r.put("devices", list);
            return r.toString();
        } catch (SecurityException e) {
            return "{\"error\":\"permission\"}";
        } catch (Exception e) {
            return "{\"error\":\"fail\"}";
        }
    }

    void connect(final String address) {
        io.execute(new Runnable() {
            @Override
            public void run() {
                closeQuietly();
                try {
                    BluetoothAdapter a = adapter();
                    if (a == null) throw new IOException("Sin Bluetooth");
                    try {
                        a.cancelDiscovery();
                    } catch (SecurityException ignored) {
                        // En Android 12+ requiere otro permiso; no es imprescindible.
                    }
                    BluetoothDevice d = a.getRemoteDevice(address);
                    BluetoothSocket s = open(d);
                    socket = s;
                    in = s.getInputStream();
                    out = s.getOutputStream();
                    String name = d.getName();
                    sink.event("connected", name == null ? address : name);
                } catch (SecurityException e) {
                    closeQuietly();
                    sink.event("error", "permission");
                } catch (Exception e) {
                    closeQuietly();
                    sink.event("error", String.valueOf(e.getMessage()));
                }
            }
        });
    }

    /** Prueba tres formas de abrir el canal serie: la mayoría de clones ELM327 aceptan al menos una. */
    private BluetoothSocket open(BluetoothDevice d) throws IOException {
        IOException last;
        BluetoothSocket s = null;
        try {
            s = d.createRfcommSocketToServiceRecord(SPP);
            s.connect();
            return s;
        } catch (IOException e) {
            last = e;
            closeSocket(s);
        }
        s = null;
        try {
            s = d.createInsecureRfcommSocketToServiceRecord(SPP);
            s.connect();
            return s;
        } catch (IOException e) {
            last = e;
            closeSocket(s);
        }
        s = null;
        try {
            Method m = d.getClass().getMethod("createRfcommSocket", int.class);
            s = (BluetoothSocket) m.invoke(d, 1);
            if (s == null) throw last;
            s.connect();
            return s;
        } catch (IOException e) {
            closeSocket(s);
            throw e;
        } catch (Exception e) {
            closeSocket(s);
            throw last;
        }
    }

    void command(final int id, final String cmd) {
        io.execute(new Runnable() {
            @Override
            public void run() {
                BluetoothSocket s = socket;
                if (s == null || in == null || out == null) {
                    sink.result(id, "ERROR");
                    return;
                }
                try {
                    // Descarta restos de respuestas anteriores.
                    while (in.available() > 0) {
                        if (in.read() < 0) break;
                    }
                    out.write((cmd + "\r").getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                    sink.result(id, readUntilPrompt());
                } catch (IOException e) {
                    closeQuietly();
                    sink.result(id, "ERROR");
                    sink.event("disconnected", "");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    sink.result(id, "ERROR");
                }
            }
        });
    }

    /** Lee hasta el símbolo '>' con el que el ELM327 indica que está listo. */
    private String readUntilPrompt() throws IOException, InterruptedException {
        StringBuilder sb = new StringBuilder();
        long end = System.currentTimeMillis() + READ_TIMEOUT_MS;
        while (System.currentTimeMillis() < end) {
            if (in.available() > 0) {
                int c = in.read();
                if (c < 0) throw new IOException("closed");
                if (c == '>') return sb.toString();
                sb.append((char) c);
            } else {
                Thread.sleep(8);
            }
        }
        return sb.append("\rTIMEOUT").toString();
    }

    void disconnect() {
        io.execute(new Runnable() {
            @Override
            public void run() {
                closeQuietly();
            }
        });
    }

    void shutdown() {
        closeQuietly();
        io.shutdownNow();
    }

    private void closeQuietly() {
        BluetoothSocket s = socket;
        socket = null;
        in = null;
        out = null;
        closeSocket(s);
    }

    private static void closeSocket(BluetoothSocket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (IOException ignored) {
            // nada que hacer
        }
    }
}
