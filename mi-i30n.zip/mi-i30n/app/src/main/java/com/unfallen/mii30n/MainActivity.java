package com.unfallen.mii30n;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

/**
 * Muestra la app (assets/index.html) a pantalla completa.
 * - Enlaces externos (YouTube, teléfonos) se abren en su app.
 * - Permite elegir fotos para la sección Documentos.
 * - Recibe la fecha de la ITV desde la página y programa los avisos.
 * - Da la ubicación a la página para "Dónde aparqué" y avisa del ticket.
 * - Conecta con un lector OBD ELM327 por Bluetooth y activa el modo espectáculo.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final int REQ_FILE = 1001;
    private static final int REQ_NOTIF = 1002;
    private static final int REQ_LOC = 1003;
    private static final int REQ_BT = 1004;
    private static final String BT_CONNECT = "android.permission.BLUETOOTH_CONNECT";

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private ObdClient obd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#08090A"));
        setContentView(web);

        // Sirve /assets desde un origen https estable: así localStorage e IndexedDB
        // guardan los datos del coche y las fotos entre sesiones.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(true);

        obd = new ObdClient(getApplicationContext(), new ObdClient.Sink() {
            @Override
            public void event(String type, String data) {
                js("window.obdEvent&&window.obdEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")");
            }

            @Override
            public void result(int id, String data) {
                js("window.obdResult&&window.obdResult(" + id + "," + JSONObject.quote(data) + ")");
            }
        });

        web.addJavascriptInterface(new Bridge(getApplicationContext()), "AndroidBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (HOST.equals(uri.getHost())) {
                    return false; // navegación interna
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (ActivityNotFoundException ignored) {
                    // No hay app para abrir el enlace.
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                } else {
                    geoOrigin = origin;
                    geoCallback = callback;
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                Intent pick;
                try {
                    pick = params.createIntent();
                } catch (Exception e) {
                    pick = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*");
                }
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(pick, "Elegir foto"), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback.onReceiveValue(null);
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }

        // Mantiene activa la comprobación diaria si ya había una fecha de ITV guardada.
        ItvWorker.schedule(getApplicationContext(), false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Ejecuta código en la página desde cualquier hilo. */
    private void js(final String code) {
        final WebView w = web;
        if (w == null) return;
        w.post(new Runnable() {
            @Override
            public void run() {
                w.evaluateJavascript(code, null);
            }
        });
    }

    private boolean hasBtPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(BT_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressWarnings("deprecation")
    private void applyImmersive(boolean on) {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c == null) return;
            if (on) {
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsets.Type.systemBars());
            } else {
                c.show(WindowInsets.Type.systemBars());
            }
        } else {
            View d = getWindow().getDecorView();
            d.setSystemUiVisibility(on
                    ? View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                      | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    : View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_NOTIF) {
            ItvWorker.schedule(getApplicationContext(), true);
        }
        if (requestCode == REQ_BT) {
            js("window.obdEvent&&window.obdEvent('permission','" + hasBtPermission() + "')");
        }
        if (requestCode == REQ_LOC && geoCallback != null) {
            geoCallback.invoke(geoOrigin, hasLocationPermission(), false);
            geoCallback = null;
            geoOrigin = null;
        }
    }

    /** Métodos que la página puede llamar como window.AndroidBridge.* */
    private class Bridge {
        private final Context ctx;

        Bridge(Context ctx) {
            this.ctx = ctx;
        }

        @JavascriptInterface
        public void setItvDate(String isoDate) {
            ctx.getSharedPreferences(ItvWorker.PREFS, Context.MODE_PRIVATE)
                    .edit().putString(ItvWorker.KEY_DATE, isoDate).apply();
            ItvWorker.schedule(ctx, true);
            runOnUiThread(MainActivity.this::askNotificationPermission);
        }

        @JavascriptInterface
        public void setParkingReminder(int minutes) {
            ParkingWorker.schedule(ctx, minutes);
            runOnUiThread(MainActivity.this::askNotificationPermission);
        }

        @JavascriptInterface
        public void cancelParkingReminder() {
            ParkingWorker.cancel(ctx);
        }

        /** Lista de adaptadores emparejados; si falta el permiso de Bluetooth, lo pide. */
        @JavascriptInterface
        public String obdDevices() {
            if (!hasBtPermission()) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        requestPermissions(new String[]{BT_CONNECT}, REQ_BT);
                    }
                });
                return "{\"error\":\"permission\"}";
            }
            return obd.devices();
        }

        @JavascriptInterface
        public void obdConnect(String address) {
            obd.connect(address);
        }

        @JavascriptInterface
        public void obdCmd(int id, String cmd) {
            obd.command(id, cmd);
        }

        @JavascriptInterface
        public void obdDisconnect() {
            obd.disconnect();
        }

        /** Mantiene la pantalla encendida (modo espectáculo). */
        @JavascriptInterface
        public void keepScreenOn(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            });
        }

        /** Oculta las barras del sistema (modo espectáculo). */
        @JavascriptInterface
        public void setImmersive(final boolean on) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyImmersive(on);
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        if (obd != null) obd.shutdown();
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
