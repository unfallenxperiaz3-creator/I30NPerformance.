# Mi i30 N

App Android para el Hyundai i30 N Performance (5 puertas, 2.0 T-GDi 275 CV, 2018 – 2020).
Estilo en gris oscuro, negro y la línea roja del paragolpes. Funciona sin conexión (los vídeos de YouTube sí necesitan internet).

## Qué incluye

- **Mi coche**: matrícula, km y matriculación; calcula la próxima ITV y el cambio de aceite, y avisa con notificación antes de la ITV.
- **Ficha**: motor, prestaciones, chasis, medidas y capacidades.
- **Ruidos**: qué puede ser cada ruido, qué hacer y vídeos de YouTube.
- **Revisión**: plan de mantenimiento del 2.0 T-GDi y reglas de la ITV.
- **Más**: dónde aparqué, lector OBD (ELM327 Bluetooth), diario del coche, modo espectáculo, avería o accidente, documentos, funciones N, cuidado y limpieza, reprogramación y testigos.

## Compilar desde el móvil

1. Sube `mi-i30n.zip` a un repositorio de GitHub (Add file → Upload files).
2. Crea `.github/workflows/build.yml` con el contenido de `build-movil.yml`.
3. En Releases aparece `MiI30N.apk`.
